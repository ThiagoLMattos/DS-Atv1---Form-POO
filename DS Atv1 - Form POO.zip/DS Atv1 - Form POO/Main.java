import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    
    public static void main(String[] args) {
       int x = 0;
       String nomePessoa = null;
       String emailPessoa = null;
       int idadePessoa = 0;
       Scanner input = new Scanner(System.in);
       ArrayList<Pessoa> arrPessoas = new ArrayList<Pessoa>();
       
       while (x!=6) {

            System.out.println("\nEscolha uma operação:\n1 - Cadastrar uma nova pessoa\n2 - Editar os dados de uma pessoa cadastrada\n3 - Apresentar dados de uma pessoa cadastrada\n4 - Visualizar todos dados cadastrados\n5 - Excluir dados de uma pessoa cadastrada\n6- Sair");
            x = input.nextInt();
            int indicePessoa = 0;

            switch(x) {
                case 1:
                    input.nextLine();
                    System.out.println("\nInsira o nome:");
                    nomePessoa = input.nextLine();
                    System.out.println("\nInsira a idade:");
                    idadePessoa = input.nextInt();
                    input.nextLine();
                    System.out.println("\nInsira o email:");
                    emailPessoa = input.nextLine();
                    Pessoa pessoa = new Pessoa(nomePessoa, idadePessoa, emailPessoa);
                    arrPessoas.add(pessoa);

                break;
                case 2:
                    System.out.println("\nInsira qual cadastro você deseja editar: ");
                    indicePessoa = input.nextInt();
                    if (indicePessoa < arrPessoas.size()) {
                        input.nextLine();
                        System.out.println("\nInsira o nome:");
                        nomePessoa = input.nextLine();
                        System.out.println("\nInsira a idade:");
                        idadePessoa = input.nextInt();
                        input.nextLine();
                        System.out.println("\nInsira o email:");
                        emailPessoa = input.nextLine();
                        arrPessoas.get(indicePessoa).setNome(nomePessoa);
                        arrPessoas.get(indicePessoa).setIdade(idadePessoa);
                        arrPessoas.get(indicePessoa).setEmail(emailPessoa);

                        System.out.println("\nCadastro editado com sucesso!\n");
                    } else {
                        System.out.println("\nNão há cadastro com esse índice!\n");
                    }
                break;
                case 3:
                        System.out.println("\nInsira qual cadastro você deseja visualizar: ");
                        indicePessoa = input.nextInt();
                        if (indicePessoa < arrPessoas.size()) {
                            nomePessoa = arrPessoas.get(indicePessoa).getNome();
                            idadePessoa = arrPessoas.get(indicePessoa).getIdade();
                            emailPessoa = arrPessoas.get(indicePessoa).getEmail();
                            System.out.println("\nNome: "+nomePessoa+" / Idade: "+idadePessoa+" / Email: "+emailPessoa+"\n");
                        } else {
                            System.out.println("\nNão há casdastro com esse indíce!\n");
                        }

                break;
                case 4:

                for (Pessoa i : arrPessoas) {
                    System.out.printf(indicePessoa +" - " + i.toString()+"\n");
                    indicePessoa++;
                }

                break;
                case 5:
                    System.out.println("\nInsira qual cadastro você deseja apagar: ");
                    indicePessoa = input.nextInt();
                    if (indicePessoa < arrPessoas.size()) {
                    arrPessoas.remove(indicePessoa);
                    System.out.println("\nCadastro apagado com sucesso!\n");
                    } else {
                        System.out.println("\nNão há casdastro com esse indíce!\n");
                    }



                break;
                case 6:
                    System.out.println("Saindo...");
                    input.close();
                break;

                default:
                    System.out.println("Opção Inválida, tente novamente!\n");
            }
        }
    }
}
